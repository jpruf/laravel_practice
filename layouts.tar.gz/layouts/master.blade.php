<!DOCTYPE html>
<html>
    <head>
        <title>@yield('title')</title>
        <link rel="stylesheet" href="{{URL::secure('src/css/main.css')}}"
        @('styles')
    </head>
    <body>
        <div class="main"></div>
            @include('includes/header')
            @yield('content')
        </div>
    </body>
   
</html>
